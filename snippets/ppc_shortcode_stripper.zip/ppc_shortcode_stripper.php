<?php
/*
Plugin Name: Post Pay Counter - Shortcode stripper
Plugin URI: http://postpaycounter.com/disregard-shortcodes-when-computing-word-payment
Description: Strips shortcodes from content before counting its words.
Author: Stefano Ottolenghi
Version: 1.0
Author URI: http://www.thecrowned.org/
*/

//Just type in the shortcodes (without brackets), and the text inside them won't be taken into account. Separate shortcodes with a comma.
global $ppc_shortcodes_to_strip;
$ppc_shortcodes_to_strip = "shortcode1, shortcode2";

/**
 * Works by temporarily fooling WP into thinking there's just one shortcode (the one to be deleted) and use its methods to clean the post.
 *
 * @param string $content
 * @return string content with shortcodes striped
 */
function ppc_count_words_strip_shortcode( $content ) {
    global $shortcode_tags, $ppc_shortcodes_to_strip;

    $stack = $shortcode_tags;
    $shortcode_tags_explode = explode( ",", $ppc_shortcodes_to_strip );
    $shortcode_tags = array();
    foreach( $shortcode_tags_explode as $single )
		$shortcode_tags[trim( $single )] = 1;

    $content = strip_shortcodes( $content );

    $shortcode_tags = $stack;
    return $content;
}

add_filter( 'ppc_count_post_words_post_content_start', 'ppc_count_words_strip_shortcode' ); 
?>
