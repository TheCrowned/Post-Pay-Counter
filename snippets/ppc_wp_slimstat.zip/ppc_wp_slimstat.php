<?php
/*
Plugin Name: Post Pay Counter - WP Slimstat integration
Plugin URI: http://www.thecrowned.org/pay-writers-per-visit-wordpress
Description: Allows integration of WP Slimstat data with Post Pay Counter.
Author: Stefano Ottolenghi
Version: 1.1
Author URI: http://www.thecrowned.org/
*/

global $ppc_wp_slimstat_include_status;

function ppc_wp_slimstat_include_file() {
	global $ppc_wp_slimstat_include_status;

	if ( ! is_file( $dir = WPMU_PLUGIN_DIR . '/wp-slimstat/admin/view/wp-slimstat-db.php' ) ) {
		if ( ! is_file( $dir = WP_PLUGIN_DIR . '/wp-slimstat/admin/view/wp-slimstat-db.php' ) )
			$dir = false;
	}

	if( $dir )
		$ppc_wp_slimstat_include_status = @include_once( $dir );
	else
		$ppc_wp_slimstat_include_status = false;
		
}
add_action( "admin_init", "ppc_wp_slimstat_include_file" );

function ppc_wp_slimstat_views( $post ) {
	global $ppc_wp_slimstat_include_status;

	if( $ppc_wp_slimstat_include_status ) {
		$filters = 'content_id equals ' . $post->ID;
		wp_slimstat_db::init( $filters );
		$count_post_views = wp_slimstat_db::count_records( "id", "", false );
	} else {
		$count_post_views = -1;
	}
	
	return $count_post_views;
}
?>

